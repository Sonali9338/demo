<?php
session_start();
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $q = mysqli_query($conn, "SELECT * FROM users 
        WHERE email='$email' AND password='$password'");

    if (mysqli_num_rows($q) == 1) {
        $_SESSION['user'] = $email;
        header("Location: complaint_form.php");
        exit();
    } else {
        echo "Invalid Login";
    }
}
?>

<h2>Login</h2>

<form method="post">
<input type="email" name="email" placeholder="Email" required><br><br>
<input type="password" name="password" placeholder="Password" required><br><br>

<button type="submit">Login</button>
</form>