<?php 
include("db.php"); 
?>
<link rel="stylesheet" href="css/style.css">

<div class="table-box">
<h2>Complaint Status</h2>

<table>
<tr>
<th>ID</th>
<th>Name</th>
<th>Mobile</th>
<th>Title</th>
<th>Location</th>
<th>Date</th>
<th>Status</th>
</tr>

<?php
$res = mysqli_query($conn,"SELECT * FROM complaints");

while($row = mysqli_fetch_assoc($res)){
echo "<tr>
<td>".$row['id']."</td>
<td>".$row['name']."</td>
<td>".$row['mobile']."</td>
<td>".$row['title']."</td>
<td>".$row['location']."</td>
<td>".$row['date']."</td>
<td>".$row['status']."</td>
</tr>";
}
?>

</table>
</div>