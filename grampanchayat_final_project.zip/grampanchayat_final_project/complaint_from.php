<?php
session_start();
include "db.php";

if(!isset($_SESSION['user'])){
    header("Location: login.php");
    exit();
}
?>

<h2>Complaint Form</h2>

<form action="complaint.php" method="post" enctype="multipart/form-data">

<input type="text" name="name" placeholder="Name" required><br><br>
<input type="text" name="mobile" placeholder="Mobile" required><br><br>
<input type="email" name="email" placeholder="Email"><br><br>
<input type="text" name="address" placeholder="Address" required><br><br>

<input type="text" name="title" placeholder="Title" required><br><br>

<select name="category">
    <option>Water</option>
    <option>Road</option>
    <option>Electricity</option>
    <option>Sanitation</option>
</select><br><br>

<textarea name="description" placeholder="Description"></textarea><br><br>

<input type="text" name="location" placeholder="Location"><br><br>

<input type="date" name="date"><br><br>
<input type="time" name="time"><br><br>

<input type="file" name="image"><br><br>

<button>Submit Complaint</button>

</form>