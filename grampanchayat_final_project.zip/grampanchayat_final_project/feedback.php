<?php
include("db.php");

$cid=$_POST['cid'];
$rating=$_POST['rating'];
$comment=$_POST['comment'];

mysqli_query($conn,"INSERT INTO feedback(complaint_id,rating,comment)
VALUES('$cid','$rating','$comment')");

echo "Feedback Submitted";
?>