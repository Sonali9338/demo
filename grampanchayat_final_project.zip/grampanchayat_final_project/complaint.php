<?php
include "db.php";

$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$address = $_POST['address'];
$title = $_POST['title'];
$category = $_POST['category'];
$description = $_POST['description'];
$location = $_POST['location'];
$date = $_POST['date'];
$time = $_POST['time'];

$image = $_FILES['image']['name'];
move_uploaded_file($_FILES['image']['tmp_name'], "uploads/".$image);

mysqli_query($conn,"INSERT INTO complaints
(name,mobile,email,address,title,category,description,location,date,time,image,status)
VALUES
('$name','$mobile','$email','$address','$title','$category','$description','$location','$date','$time','$image','Pending')");

echo "Complaint Submitted Successfully <a href='complaint_form.php'>Back</a>";
?>