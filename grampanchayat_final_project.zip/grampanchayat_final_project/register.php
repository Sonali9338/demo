<?php
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if($name && $email && $password){
        mysqli_query($conn,"INSERT INTO users(name,email,password)
        VALUES('$name','$email','$password')");

        echo "<script>alert('Registered Successfully'); window.location='login.php';</script>";
    }
}
?>

<link rel="stylesheet" href="css/style.css">

<div class="container">
<h2>Register</h2>

<form method="post">
<input type="text" name="name" placeholder="Name" required>
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Password" required>

<button type="submit">Register</button>
</form>

<a href="login.php" class="link">Already have account? Login</a>
</div>