
<?php
$conn = mysqli_connect("localhost","root","","grampanchayat");

if(!$conn){
    die("Connection Failed");
}
?>